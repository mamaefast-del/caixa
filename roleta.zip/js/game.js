// Configurações da roleta
const ITEM_WIDTH = 130; // Largura de cada item (120px + 10px de margin)
const VISIBLE_ITEMS = 5; // Quantos itens são visíveis
const CENTER_POSITION = Math.floor(VISIBLE_ITEMS / 2); // Posição central (índice 2)

// Elementos DOM
const reelStrip = document.getElementById('reelStrip');
const gameData = document.getElementById('gameData');
const btnJogar = document.querySelector('.btn-jogar');
const modal = document.getElementById('resultadoModal');
const modalTitle = document.getElementById('modalTitle');
const modalImage = document.getElementById('modalImage');
const modalText = document.getElementById('modalText');
const modalContinueBtn = document.getElementById('modalContinueBtn');

// Dados do jogo
let segmentos = [];
let premiosInfo = {};
let isSpinning = false;
let spinSound = null;

// Inicializar som
function initSound() {
    try {
        spinSound = new Audio('sound/reel-spin.mp3');
        spinSound.volume = 0.5;
        spinSound.loop = true;
    } catch (error) {
        console.log('Som não disponível:', error);
    }
}

// Carregar dados do jogo
function loadGameData() {
    try {
        const segmentosData = gameData.getAttribute('data-segmentos');
        if (segmentosData) {
            segmentos = JSON.parse(segmentosData);
        }
        
        // Carregar informações dos prêmios do HTML
        const reelItems = document.querySelectorAll('.reel-item');
        reelItems.forEach((item, index) => {
            const valor = item.getAttribute('data-valor');
            const img = item.querySelector('img');
            const textElement = item.querySelector('.reel-item-text, .item-nao-ganhou');
            const valorElement = item.querySelector('.valor');
            
            premiosInfo[valor] = {
                nome: textElement ? textElement.textContent.trim() : 'Prêmio',
                imagem: img ? img.src : '',
                valor: valorElement ? valorElement.textContent.trim() : 'R$ 0,00'
            };
        });
        
        console.log('Segmentos carregados:', segmentos.length);
        console.log('Prêmios info:', premiosInfo);
        
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
    }
}

// Duplicar itens para criar loop infinito
function setupInfiniteLoop() {
    const originalItems = Array.from(reelStrip.children);
    const totalItems = originalItems.length;
    
    // Adicionar itens no início (para scroll para a esquerda)
    for (let i = 0; i < totalItems; i++) {
        const clone = originalItems[i].cloneNode(true);
        reelStrip.insertBefore(clone, reelStrip.firstChild);
    }
    
    // Adicionar itens no final (para scroll para a direita)
    for (let i = 0; i < totalItems; i++) {
        const clone = originalItems[i].cloneNode(true);
        reelStrip.appendChild(clone);
    }
    
    // Posicionar no meio (nos itens originais)
    const startPosition = -(totalItems * ITEM_WIDTH);
    reelStrip.style.transform = `translateX(${startPosition}px)`;
    
    console.log('Loop infinito configurado. Total de itens:', reelStrip.children.length);
}

// Calcular posição para centralizar um item específico
function calculateCenterPosition(targetIndex) {
    const totalItems = reelStrip.children.length;
    const originalItemsCount = Math.floor(totalItems / 3); // Dividido por 3 porque temos: clones + originais + clones
    
    // Ajustar índice para os itens originais (meio da lista)
    const adjustedIndex = originalItemsCount + (targetIndex % originalItemsCount);
    
    // Calcular posição para centralizar o item
    const containerWidth = reelStrip.parentElement.offsetWidth;
    const centerOffset = containerWidth / 2 - ITEM_WIDTH / 2;
    const targetPosition = -(adjustedIndex * ITEM_WIDTH) + centerOffset;
    
    return targetPosition;
}

// Obter o item que está no centro após a animação
function getCenterItem() {
    const containerWidth = reelStrip.parentElement.offsetWidth;
    const centerOffset = containerWidth / 2;
    
    // Obter posição atual da strip
    const currentTransform = reelStrip.style.transform;
    const currentX = currentTransform ? parseFloat(currentTransform.match(/-?\d+\.?\d*/)[0]) : 0;
    
    // Calcular qual item está no centro
    const centerPosition = Math.abs(currentX) + centerOffset;
    const centerItemIndex = Math.round(centerPosition / ITEM_WIDTH);
    
    // Garantir que o índice está dentro dos limites
    const totalItems = reelStrip.children.length;
    const validIndex = Math.max(0, Math.min(centerItemIndex, totalItems - 1));
    
    const centerItem = reelStrip.children[validIndex];
    const itemValue = centerItem ? centerItem.getAttribute('data-valor') : 'nao_ganhou';
    
    console.log('Item no centro:', itemValue, 'Índice:', validIndex);
    return itemValue;
}

// Executar o giro da roleta
function spinReel(targetPrize) {
    if (isSpinning) return;
    
    isSpinning = true;
    btnJogar.disabled = true;
    btnJogar.classList.add('loading');
    
    // Tocar som
    if (spinSound) {
        spinSound.currentTime = 0;
        spinSound.play().catch(e => console.log('Erro ao tocar som:', e));
    }
    
    // Adicionar classe de animação
    reelStrip.parentElement.classList.add('spinning');
    
    // Encontrar índice do prêmio alvo nos itens originais
    let targetIndex = -1;
    const originalItemsCount = Math.floor(reelStrip.children.length / 3);
    
    for (let i = originalItemsCount; i < originalItemsCount * 2; i++) {
        const item = reelStrip.children[i];
        if (item && item.getAttribute('data-valor') === targetPrize) {
            targetIndex = i - originalItemsCount; // Converter para índice dos itens originais
            break;
        }
    }
    
    // Se não encontrou o prêmio, usar um aleatório
    if (targetIndex === -1) {
        targetIndex = Math.floor(Math.random() * originalItemsCount);
        console.warn('Prêmio não encontrado, usando índice aleatório:', targetIndex);
    }
    
    console.log('Girando para prêmio:', targetPrize, 'Índice:', targetIndex);
    
    // Calcular posição final
    const finalPosition = calculateCenterPosition(targetIndex);
    
    // Adicionar voltas extras para efeito visual (3-5 voltas completas)
    const extraSpins = (3 + Math.random() * 2) * originalItemsCount * ITEM_WIDTH;
    const totalDistance = finalPosition - extraSpins;
    
    // Aplicar animação
    reelStrip.style.transition = 'transform 3s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
    reelStrip.style.transform = `translateX(${totalDistance}px)`;
    
    // Aguardar fim da animação
    setTimeout(() => {
        // Parar som
        if (spinSound) {
            spinSound.pause();
            spinSound.currentTime = 0;
        }
        
        // Remover classe de animação
        reelStrip.parentElement.classList.remove('spinning');
        
        // Verificar resultado
        const resultPrize = getCenterItem();
        console.log('Resultado final:', resultPrize);
        
        // Mostrar resultado
        showResult(resultPrize);
        
        isSpinning = false;
        btnJogar.disabled = false;
        btnJogar.classList.remove('loading');
        
    }, 3000);
}

// Mostrar resultado no modal
function showResult(prizeKey) {
    const prizeInfo = premiosInfo[prizeKey] || premiosInfo['nao_ganhou'];
    const isWin = prizeKey !== 'nao_ganhou';
    
    // Configurar modal
    modalTitle.textContent = isWin ? '🎉 PARABÉNS!' : '😔 QUE PENA!';
    modalText.textContent = isWin ? 
        `Você ganhou: ${prizeInfo.nome}!` : 
        'Não foi dessa vez, tente novamente!';
    
    // Configurar imagem
    if (prizeInfo.imagem && isWin) {
        modalImage.src = prizeInfo.imagem;
        modalImage.style.display = 'block';
    } else {
        modalImage.style.display = 'none';
    }
    
    // Mostrar modal
    modal.style.display = 'flex';
    
    // Efeito de confete se ganhou
    if (isWin) {
        setTimeout(() => {
            if (typeof confetti !== 'undefined') {
                confetti({
                    particleCount: 100,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            }
        }, 500);
    }
}

// Verificar se há resultado da sessão PHP
function checkSessionResult() {
    const premioReal = gameData.getAttribute('data-premio-real');
    const premioChave = gameData.getAttribute('data-premio-chave');
    
    if (premioReal !== null && premioChave !== null) {
        console.log('Resultado da sessão:', premioChave, premioReal);
        
        // Executar giro automático para o prêmio
        setTimeout(() => {
            spinReel(premioChave);
        }, 500);
        
        // Limpar atributos para evitar repetição
        gameData.removeAttribute('data-premio-real');
        gameData.removeAttribute('data-premio-chave');
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    console.log('Inicializando jogo...');
    
    initSound();
    loadGameData();
    setupInfiniteLoop();
    checkSessionResult();
    
    // Botão do modal
    modalContinueBtn.addEventListener('click', function() {
        modal.style.display = 'none';
        
        // Mostrar botão "Jogar Novamente"
        const btnJogarNovamente = document.getElementById('btnJogarNovamente');
        if (btnJogarNovamente) {
            btnJogarNovamente.style.display = 'inline-block';
        }
    });
    
    // Fechar modal clicando fora
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modalContinueBtn.click();
        }
    });
});

// Debug: mostrar posição atual
function debugCurrentPosition() {
    const centerItem = getCenterItem();
    console.log('Item atual no centro:', centerItem);
}

// Adicionar debug no console
window.debugReel = debugCurrentPosition;